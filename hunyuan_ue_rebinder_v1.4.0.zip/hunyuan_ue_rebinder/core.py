"""Scene operations. All geometry changes are limited to owned copies."""
import bpy
import hashlib
import json
import math
import uuid
from collections import defaultdict, deque
from array import array
from mathutils import Vector, Matrix, Quaternion
from mathutils.bvhtree import BVHTree
from .mapping import roles, auto_map, region, is_finger, is_helper

OWNER = 'hunyuan_ue_rebinder'


def resolve_rig(obj):
    if obj is None:
        raise ValueError('请先选择 UE 骨架和混元骨架。')
    if obj.type == 'ARMATURE':
        return obj
    candidates = [o for o in obj.children_recursive if o.type == 'ARMATURE']
    if len(candidates) != 1:
        raise ValueError(f'{obj.name} 下有 {len(candidates)} 个骨架，请直接选择其中一个骨架对象。')
    return candidates[0]


def meshes_for(rig, scene):
    return [o for o in scene.objects if o.type == 'MESH' and not o.get(OWNER) and
            any(m.type == 'ARMATURE' and m.object == rig for m in o.modifiers)]


def inputs(p):
    src, dst = resolve_rig(p.source), resolve_rig(p.target)
    if src == dst or src.data == dst.data:
        raise ValueError('输入必须是两套独立骨架。')
    for obj in (src, dst):
        if obj.get(OWNER):
            raise ValueError('请选择原始骨架，不要把本工具的预览或结果再次作为输入。')
        scales = obj.matrix_world.to_scale()
        if min(scales) <= 1e-8 or obj.matrix_world.determinant() <= 0:
            raise ValueError(f'{obj.name} 有负缩放或零缩放，请先修正输入变换。')
        if max(scales)/min(scales) > 1.0001:
            raise ValueError(f'{obj.name} 有非均匀缩放；请在副本上正确应用缩放后再处理。')
    return src, dst


def has_root(rig):
    return any(b.name.casefold()=='root' for b in rig.data.bones)


def selected_meshes(p):
    return [i.obj for i in p.meshes if i.enabled and i.obj and i.obj.type == 'MESH']


def mapping_dict(p):
    return {i.source: i.target for i in p.mapping if i.target}


def inspect(context, p):
    src, dst = inputs(p)
    objects = meshes_for(src, context.scene)
    if not objects:
        raise ValueError('混元骨架没有通过 Armature 修改器绑定的网格。')
    p.meshes.clear()
    for obj in objects:
        item = p.meshes.add(); item.obj = obj; item.enabled = True
    donors = meshes_for(dst, context.scene)
    donors.sort(key=lambda o: (('lod0' in o.name.lower()), len(o.data.vertices)), reverse=True)
    p.donor = donors[0] if donors else None
    p.source_rig = src; p.target_rig = dst
    p.mapping.clear()
    matches = auto_map(src, dst)
    used = defaultdict(float)
    for obj in objects:
        for v in obj.data.vertices:
            for g in v.groups:
                name = obj.vertex_groups[g.group].name
                if name in src.data.bones:
                    used[name] += g.weight
    for b in src.data.bones:
        row = p.mapping.add(); row.source = b.name; row.target = matches[b.name]
        row.weighted = used[b.name] > 1e-6
    p.stage = 1
    warnings = []
    if not donors:
        warnings.append('UE 骨架没有参考网格：仍可用原权重换绑，混合权重功能自动回退。')
    sr,tr=roles(src),roles(dst)
    if all(role in sr and role in tr for role in ('pelvis','neck')):
        sl=(src.matrix_world@src.pose.bones[sr['neck']].head-src.matrix_world@src.pose.bones[sr['pelvis']].head).length
        tl=(dst.matrix_world@dst.data.bones[tr['neck']].head_local-dst.matrix_world@dst.data.bones[tr['pelvis']].head_local).length
        if sl>1e-8 and abs(tl/sl-1)>.2:
            warnings.append(f'目标躯干长度是源的 {tl/sl:.2f} 倍，固定参考骨架会改变体态。可选择保留体态并使用独立 Skeleton。')
    if dst.get('hur_requires_separate_skeleton'):
        warnings.append('当前为体态适配骨架：UE 中使用独立 Skeleton，不直接共用原 Manny Skeleton。')
    if not any(is_finger(b.name) for b in src.data.bones):
        warnings.append('源骨架没有独立手指；默认保留整手绑定。')
    if any(o.data.shape_keys for o in objects):
        warnings.append('检测到形态键；需显式选择烘焙当前形态，否则禁止生成。')
    roots = [b.name for b in dst.data.bones if b.parent is None]
    if len(roots)>1 or not has_root(dst):
        warnings.append('UE 输入缺少单一 root；可启用「缺失时补回 root」。')
    p.message = f'找到 {len(objects)} 个源网格；源 {len(src.data.bones)} 骨，目标 {len(dst.data.bones)} 骨。'
    p.warnings = '\n'.join(warnings)
    p.input_stamp = ''
    return p.message


def check_mapping(p):
    src, dst = inputs(p)
    objects = selected_meshes(p)
    if not objects:
        raise ValueError('至少启用一个混元网格。')
    mapping = mapping_dict(p)
    if p.donor and not any(m.type=='ARMATURE' and m.object==dst for m in p.donor.modifiers):
        raise ValueError('UE 参考网格必须绑定到所选目标骨架；不使用参考网格时可清空此项。')
    for source, target in mapping.items():
        if source not in src.data.bones or target not in dst.data.bones:
            raise ValueError(f'无效映射：{source} → {target}。请重新检查输入或修正映射。')
    missing = set()
    for obj in objects:
        if not any(m.type == 'ARMATURE' and m.object == src for m in obj.modifiers):
            raise ValueError(f'{obj.name} 已不再绑定选定的源骨架，请重新检查输入。')
        if obj.data.shape_keys and not p.bake_shapes:
            raise ValueError(f'{obj.name} 有形态键。启用「烘焙当前形态（不保留形态键）」后才能继续。')
        for v in obj.data.vertices:
            groups = [(obj.vertex_groups[g.group].name, g.weight) for g in v.groups
                      if g.weight > 1e-8 and obj.vertex_groups[g.group].name in src.data.bones]
            if not groups:
                raise ValueError(f'{obj.name} 的顶点 {v.index} 没有有效骨骼权重，请先修正源模型。')
            missing.update(n for n,w in groups if not mapping.get(n))
    if missing:
        raise ValueError('以下参与蒙皮的源骨骼未映射：' + '、'.join(sorted(missing)))
    helpers = [n for n in mapping.values() if is_helper(n)]
    if helpers:
        # Helper mappings are harmless unless actually weighted; stop weighted helper assignments.
        used = {obj.vertex_groups[g.group].name for obj in objects for v in obj.data.vertices for g in v.groups if g.weight>1e-8}
        if any(s in used and t in helpers for s,t in mapping.items()):
            raise ValueError('有蒙皮权重被映射到 IK / 辅助骨，请改到对应的变形骨。')
    return src, dst, objects, mapping


def stamp(p):
    """Detect source/reference edits between preview and bind. Preview edits are intentionally allowed."""
    src, dst = inputs(p)
    h = hashlib.sha256()
    def add(value): h.update(repr(value).encode('utf8'))
    add(mapping_dict(p)); add((p.fit_mode,p.pose_fit_reference,p.head_anchor,p.head_size,p.hand_size,p.bake_shapes,p.add_root,p.stabilize_fit,p.fit_stability))
    for rig in (src, dst):
        add(rig.name); add(tuple(tuple(r) for r in rig.matrix_world))
        for b in rig.data.bones:
            add((b.name,b.parent.name if b.parent else '',tuple(tuple(r) for r in b.matrix_local),b.use_deform))
        if rig == src:
            for b in rig.pose.bones: add(tuple(tuple(r) for r in b.matrix))
    for obj in selected_meshes(p)+([p.donor] if p.donor else []):
        add(obj.name);add(tuple(tuple(r) for r in obj.matrix_world));add(tuple((m.name,m.type,m.show_viewport) for m in obj.modifiers))
        verts=array('f',[0.0])*(len(obj.data.vertices)*3);obj.data.vertices.foreach_get('co',verts);h.update(verts.tobytes())
        add([tuple(e.vertices) for e in obj.data.edges])
        add([tuple(f.vertices) for f in obj.data.polygons])
        add([(g.name,g.index) for g in obj.vertex_groups])
        for v in obj.data.vertices:add(tuple((g.group,round(g.weight,7)) for g in v.groups))
        if obj.data.shape_keys:add([(k.name,k.value) for k in obj.data.shape_keys.key_blocks])
    return h.hexdigest()


def activate(context, obj):
    if context.object and context.object.mode != 'OBJECT': bpy.ops.object.mode_set(mode='OBJECT')
    for o in context.selected_objects:o.select_set(False)
    obj.hide_set(False);obj.hide_viewport=False;obj.select_set(True);context.view_layer.objects.active=obj


def owned_collection(context, label):
    c=bpy.data.collections.new(label);context.scene.collection.children.link(c)
    c[OWNER]=uuid.uuid4().hex
    return c


def remove_owned(collection):
    if not collection or not collection.get(OWNER):return
    for obj in list(collection.objects):
        if obj.get(OWNER):
            data=obj.data
            bpy.data.objects.remove(obj,do_unlink=True)
            if data and data.users==0:
                if isinstance(data,bpy.types.Mesh):bpy.data.meshes.remove(data)
                elif isinstance(data,bpy.types.Armature):bpy.data.armatures.remove(data)
    if not collection.objects and not collection.children:bpy.data.collections.remove(collection)


def copy_rig(context, reference, collection, add_root):
    obj=reference.copy();obj.data=reference.data.copy();obj.name='UE_换绑骨架'
    collection.objects.link(obj);obj[OWNER]=collection[OWNER]
    obj.parent=None;obj.matrix_world=reference.matrix_world.copy();obj.animation_data_clear()
    for pb in obj.pose.bones:
        pb.matrix_basis=Matrix.Identity(4)
        for c in list(pb.constraints):pb.constraints.remove(c)
    if add_root and not has_root(obj):
        activate(context,obj);bpy.ops.object.mode_set(mode='EDIT')
        root=obj.data.edit_bones.new('root');root.head=(0,0,0);root.tail=(0,max(.01,max(b.length for b in obj.data.edit_bones)*.1),0)
        root.use_deform=False
        for b in obj.data.edit_bones:
            if b!=root and b.parent is None:b.parent=root
        bpy.ops.object.mode_set(mode='OBJECT')
    obj.data.pose_position='POSE';obj.data.display_type='STICK';obj.show_in_front=True
    return obj


def anatomical_basis(rig, pose=False):
    found=roles(rig)
    def pt(n):return rig.matrix_world @ (rig.pose.bones[n].head if pose else rig.data.bones[n].head_local)
    if all(r in found for r in ('head','pelvis')):
        up=(pt(found['head'])-pt(found['pelvis'])).normalized()
    else:up=(rig.matrix_world.to_quaternion()@Vector((0,0,1))).normalized()
    if all(r in found for r in ('upperarm_l','upperarm_r')):
        lateral=pt(found['upperarm_l'])-pt(found['upperarm_r'])
    else:lateral=rig.matrix_world.to_quaternion()@Vector((1,0,0))
    lateral=(lateral-up*lateral.dot(up)).normalized()
    front=lateral.cross(up).normalized()
    return up,front


def frame(a,b,front):
    y=(b-a).normalized();z=front-y*front.dot(y)
    if z.length<1e-5:
        seed=min((Vector((1,0,0)),Vector((0,1,0)),Vector((0,0,1))),key=lambda v:abs(v.dot(y)))
        z=seed-y*seed.dot(y)
    z.normalize();x=y.cross(z).normalized()
    m=Matrix((x,y,z)).transposed().to_4x4();m.translation=a;return m


def fit_segment(a,b,c,d,src_front,dst_front,radial):
    if (b-a).length<1e-7 or (d-c).length<1e-7:
        return Matrix.Translation(c)@Matrix.Scale(radial,4)@Matrix.Translation(-a)
    return frame(c,d,dst_front)@Matrix.Diagonal((radial,(d-c).length/(b-a).length,radial,1))@frame(a,b,src_front).inverted()


def geometry_height(objects,up):
    values=[(o.matrix_world@v.co).dot(up) for o in objects for v in o.data.vertices]
    return (min(values),max(values)) if values else (0,0)


def transforms(p, src, dst, mapping, world_points):
    if p.fit_mode=='POSE':
        from .pose_alignment import solve
        return solve(src,dst,mapping)[0]
    sup,sfront=anatomical_basis(src,True);tup,tfront=anatomical_basis(dst)
    sr,tr=roles(src),roles(dst)
    sh=lambda n:src.matrix_world@src.pose.bones[n].head
    th=lambda n:dst.matrix_world@dst.data.bones[n].head_local
    sb=[v.dot(sup) for v in world_points]
    smin,smax=min(sb),max(sb)
    dmin,dmax=geometry_height([p.donor],tup) if p.donor else (0,0)
    if dmax-dmin<1e-7:
        vals=[th(n).dot(tup) for n in dst.data.bones.keys()]
        dmin,dmax=min(vals),max(vals)
        # Head bone tails from FBX are not anatomical head height.
        dmax+=max(.001,(dmax-dmin)*.10)
    scale=(dmax-dmin)/max(smax-smin,1e-6)
    rotate=frame(Vector(),tup,tfront).to_quaternion() @ frame(Vector(),sup,sfront).to_quaternion().inverted()
    global_r=rotate.to_matrix().to_4x4()@Matrix.Scale(scale,4)
    # Different rigs place the first spine joint at very different fractions of the torso.
    # Fit anatomical pelvis-to-neck landmarks continuously, rather than compressing the
    # source pelvis mesh into Manny's very short pelvis-to-spine_01 offset.
    anchors={}
    inverse={t:s for s,t in mapping.items()}
    sp=inverse.get(tr.get('pelvis'));sn=inverse.get(tr.get('neck'))
    if sp and sn:
        pelvis,neck=src.data.bones[sp],src.data.bones[sn]
        a,b=sh(sp),sh(sn);c,d=th(mapping[sp]),th(mapping[sn])
        length=(b-a).dot(sup)
        if abs(length)>1e-6:
            for name in mapping:
                bone=src.data.bones[name]
                if bone==pelvis or bone==neck or (pelvis in bone.parent_recursive and bone in neck.parent_recursive):
                    fraction=max(0,min(1,(sh(name)-a).dot(sup)/length))
                    anchors[name]=c.lerp(d,fraction)
    head_source=inverse.get(tr.get('head'))
    if head_source and p.head_anchor=='HEIGHT':
        a=sh(head_source);c=th(mapping[head_source]);head_scale=scale*p.head_size
        anchors[head_source]=c+tup*(dmax-head_scale*(smax-a.dot(sup))-c.dot(tup))
    result={}
    for name,target in mapping.items():
        a,c=sh(name),anchors.get(name,th(target))
        target_bone=dst.data.bones[target]
        queue=deque(src.data.bones[name].children);next_name=None
        while queue:
            child=queue.popleft();mapped=mapping.get(child.name)
            if mapped and mapped!=target and target_bone in dst.data.bones[mapped].parent_recursive:
                next_name=child.name;break
            queue.extend(child.children)
        if p.fit_mode=='ALIGNED':
            result[name]=Matrix.Identity(4);continue
        if next_name:
            result[name]=fit_segment(a,sh(next_name),c,anchors.get(next_name,th(mapping[next_name])),sfront,tfront,scale)
        else:result[name]=Matrix.Translation(c)@global_r@Matrix.Translation(-a)
        if target==tr.get('head'):
            head_scale=scale*p.head_size
            anchor=c+tup*(dmax-head_scale*(smax-a.dot(sup))-c.dot(tup)) if p.head_anchor=='HEIGHT' else c
            result[name]=Matrix.Translation(anchor)@rotate.to_matrix().to_4x4()@Matrix.Scale(head_scale,4)@Matrix.Translation(-a)
        for side in ('l','r'):
            if target==tr.get('hand_'+side) and not next_name and tr.get('middle_03_'+side):
                end=th(tr['middle_03_'+side]);mid=th(tr.get('middle_02_'+side,tr['middle_03_'+side]))
                end=end+(end-mid)*.8
                result[name]=fit_segment(a,src.matrix_world@src.pose.bones[name].tail,c,end,sfront,tfront,scale*p.hand_size)
    return result


def fitted_positions(p):
    if p.fit_mode=='POSE' and p.pose_fit_reference:
        from .pose_alignment import reference_positions
        src,dst=inputs(p)
        return reference_positions(src,dst,mapping_dict(p))
    return None


def show_stage(p, which):
    for col,visible in [(p.preview_collection,which=='PREVIEW'),(p.result_collection,which=='RESULT')]:
        if col:
            for o in col.objects:o.hide_set(not visible);o.hide_render=not visible
    if p.hide_inputs:
        src,dst=inputs(p)
        objects=[src,dst]+selected_meshes(p)+meshes_for(dst,p.id_data)
        if p.donor:objects.append(p.donor)
        # Save visibility before the first temporary hide, and restore exactly on request.
        for obj in objects:
            if not any(i.obj==obj for i in p.visibility):
                item=p.visibility.add();item.obj=obj;item.hidden=obj.hide_get()
            obj.hide_set(True)


def restore_inputs(p):
    for item in p.visibility:
        if item.obj:item.obj.hide_set(item.hidden)
    p.visibility.clear()


def preview(context,p):
    src,dst,objects,mapping=check_mapping(p)
    # Source/reference must be evaluated even if previous preview hid them.
    restore_inputs(p)
    context.view_layer.update()
    before_stamp=stamp(p)
    col=owned_collection(context,'换绑_对齐预览')
    created=[]
    try:
        rig=copy_rig(context,dst,col,p.add_root)
        positions=fitted_positions(p)
        if positions is not None:
            from .pose_alignment import apply_reference
            apply_reference(context,rig,positions)
        dg=context.evaluated_depsgraph_get()
        all_points=[]
        for source in objects:
            evaluated=source.evaluated_get(dg)
            mesh_data=bpy.data.meshes.new_from_object(evaluated,preserve_all_data_layers=True,depsgraph=dg)
            obj=source.copy();obj.data=mesh_data;col.objects.link(obj);obj[OWNER]=col[OWNER]
            obj.name='预览_'+source.name;obj.animation_data_clear()
            obj.parent=None;obj.matrix_world=Matrix.Identity(4)
            for m in list(obj.modifiers):obj.modifiers.remove(m)
            mesh_data.transform(source.matrix_world)
            if not mesh_data.vertices:raise ValueError(f'{source.name} 烘焙后没有顶点。')
            all_points.extend(v.co.copy() for v in mesh_data.vertices)
            obj['hur_source']=source.name
            created.append(obj)
        ts=transforms(p,src,dst,mapping,all_points)
        from . import geometry
        for obj in created:
            source_points=[v.co.copy() for v in obj.data.vertices]
            linears=[]
            for v in obj.data.vertices:
                entries=[(obj.vertex_groups[g.group].name,g.weight) for g in v.groups
                         if g.weight>1e-8 and obj.vertex_groups[g.group].name in src.data.bones]
                total=sum(w for _,w in entries)
                if total<=1e-8:raise ValueError(f'{obj.name} 顶点 {v.index} 烘焙后丢失骨骼权重。')
                linear=Matrix(((0,0,0),(0,0,0),(0,0,0)))
                for n,w in entries:linear+=ts[n].to_3x3()*(w/total)
                linears.append([list(row) for row in linear])
                v.co=sum(((ts[n]@v.co)*w for n,w in entries),Vector())/total
            obj.data.update()
            geometry.store_reference(obj,source_points,linears)
            if p.stabilize_fit and p.fit_mode=='AUTO':
                obj['hur_fit_guard']=json.dumps(geometry.stabilize(obj,p.fit_stability))
        old_preview=p.preview_collection
        p.preview_collection=col;p.preview_rig=rig;p.input_stamp=before_stamp
        if p.result_collection:
            for o in p.result_collection.objects:o.hide_set(True);o.hide_render=True
        p.result_collection=None;p.result_rig=None
        remove_owned(old_preview)
        p.stage=2;p.report='';p.message='对齐预览已生成。可以在编辑模式调整预览网格，然后生成绑定。'
        if p.fit_mode=='POSE':
            from .pose_alignment import report
            alignment=report(src,dst,mapping,context.scene.unit_settings.scale_length,p.pose_fit_reference)
            col['hur_pose_alignment']=json.dumps(alignment,ensure_ascii=False)
            p.message+=f" 仅匹配姿势：最大关节偏差 {alignment['max_joint_gap_m']*100:.1f} cm；请检查肩、肘、膝位置后绑定。"
            if p.pose_fit_reference:p.message+=' 骨架位置已贴合；UE 需设置位移重定向。'
        show_stage(p,'PREVIEW');activate(context,created[0])
    except Exception:
        if context.object and context.object.mode!='OBJECT':bpy.ops.object.mode_set(mode='OBJECT')
        remove_owned(col);raise


def barycentric(p,a,b,c):
    u=b-a;v=c-a;w=p-a
    aa=u.dot(u);ab=u.dot(v);bb=v.dot(v);det=aa*bb-ab*ab
    if abs(det)<1e-18:return (1,0,0)
    y=(bb*w.dot(u)-ab*w.dot(v))/det;z=(aa*w.dot(v)-ab*w.dot(u))/det
    vals=[max(0,1-y-z),max(0,y),max(0,z)];return [x/sum(vals) for x in vals]


class Donor:
    def __init__(self,obj,rig,joint_offsets=None):
        self.coords=[obj.matrix_world@v.co for v in obj.data.vertices]
        self.weights=[{obj.vertex_groups[g.group].name:g.weight for g in v.groups
                       if g.weight>1e-8 and obj.vertex_groups[g.group].name in rig.data.bones and not is_helper(obj.vertex_groups[g.group].name)} for v in obj.data.vertices]
        if joint_offsets:
            for i,weights in enumerate(self.weights):
                total=sum(weights.values())
                if total>1e-8:
                    self.coords[i]+=sum((joint_offsets.get(n,Vector())*w for n,w in weights.items()),Vector())/total
        self.parts=defaultdict(list);rr=roles(rig)
        obj.data.calc_loop_triangles()
        for tri in obj.data.loop_triangles:
            votes=defaultdict(float)
            for i in tri.vertices:
                for name,w in self.weights[i].items():votes[region(name,rr)]+=w
            if not votes:continue
            dominant=max(votes,key=votes.get)
            for r,w in votes.items():
                if r==dominant or w>.35:self.parts[r].append(tuple(tri.vertices))
        self.trees={r:BVHTree.FromPolygons(self.coords,ts,all_triangles=True) for r,ts in self.parts.items()}

    def sample(self,point,votes,max_distance):
        result=defaultdict(float);coverage=0
        for reg,vote in votes.items():
            if reg not in self.trees or vote<.001:continue
            hit,_,idx,distance=self.trees[reg].find_nearest(point)
            if hit is None or distance>=max_distance:continue
            factor=vote*(1-distance/max_distance)
            coverage+=factor
            tri=self.parts[reg][idx]
            for v,b in zip(tri,barycentric(hit,*(self.coords[i] for i in tri))):
                for n,w in self.weights[v].items():result[n]+=factor*b*w
        total=sum(result.values())
        return ({n:w/total for n,w in result.items()} if total else {}),min(1,coverage)


def write_weights(obj,weights,limit):
    used=sorted({n for row in weights for n in row})
    obj.vertex_groups.clear()
    for n in used:obj.vertex_groups.new(name=n)
    for v,row in zip(obj.data.vertices,weights):
        limited=sorted(((n,w) for n,w in row.items() if w>1e-5),key=lambda pair:-pair[1])[:limit]
        total=sum(w for _,w in limited)
        if not total:raise ValueError(f'{obj.name} 顶点 {v.index} 没有输出权重。')
        for n,w in limited:obj.vertex_groups[n].add([v.index],w/total,'REPLACE')


def smooth_weights(obj,weights,iterations):
    if not iterations:return weights
    adjacency=[[] for _ in obj.data.vertices]
    points=[obj.matrix_world@v.co for v in obj.data.vertices]
    edge_lengths=[(points[e.vertices[0]]-points[e.vertices[1]]).length for e in obj.data.edges]
    floor=max(1e-8,sorted(edge_lengths)[len(edge_lengths)//2]*.25) if edge_lengths else 1e-8
    for e,length in zip(obj.data.edges,edge_lengths):
        a,b=e.vertices;f=1/max(floor,length)
        adjacency[a].append((b,f));adjacency[b].append((a,f))
    for _ in range(iterations):
        updated=[]
        for i,row in enumerate(weights):
            neighbors=adjacency[i]
            if not neighbors:updated.append(row);continue
            total=sum(f for _,f in neighbors);mix=defaultdict(float)
            for n,w in row.items():mix[n]+=.5*w
            for j,f in neighbors:
                for n,w in weights[j].items():mix[n]+=.5*f/total*w
            updated.append(dict(mix))
        weights=updated
    return weights


def check_preview(p):
    if not p.preview_collection or not p.preview_rig:
        raise ValueError('请先生成对齐预览。')
    if stamp(p)!=p.input_stamp:
        raise ValueError('输入、骨骼映射或对齐参数已变化，请重新生成预览。')
    _,dst=inputs(p)
    errors=compare_skeleton(p.preview_rig,dst,p.add_root,fitted_positions(p))
    if errors:raise ValueError('预览骨架被修改，请重新生成预览。可编辑预览网格，但应保留目标骨架。')


def bind(context,p):
    src,dst,_,mapping=check_mapping(p);check_preview(p)
    previous_collection=p.result_collection
    previous_rig=p.result_rig
    col=owned_collection(context,'换绑_结果')
    try:
        rig=copy_rig(context,dst,col,p.add_root);rig.show_in_front=False
        positions=fitted_positions(p)
        offsets=None
        if positions is not None:
            from .pose_alignment import apply_reference
            apply_reference(context,rig,positions)
            offsets={n:point-dst.matrix_world@dst.data.bones[n].head_local for n,point in positions.items()}
        donor=Donor(p.donor,dst,offsets) if p.weight_method=='HYBRID' and p.donor else None
        rr=roles(dst)
        shoulder_points=[rig.matrix_world@rig.data.bones[rr[r]].head_local for r in ('upperarm_l','upperarm_r') if r in rr]
        shoulder_radius=(shoulder_points[0]-shoulder_points[1]).length*.48 if len(shoulder_points)==2 else 0
        max_distance=p.transfer_distance/max(context.scene.unit_settings.scale_length,1e-8)
        created=[]
        rigid_sides=set()
        for side in ('l','r'):
            target_fingers=[b.name for b in dst.data.bones if is_finger(b.name) and region(b.name,rr)=='arm_'+side]
            if not any(n in mapping.values() for n in target_fingers):rigid_sides.add(side)
        for prev in p.preview_collection.objects:
            if prev.type!='MESH' or not prev.get(OWNER):continue
            obj=prev.copy();obj.data=prev.data.copy();col.objects.link(obj);obj[OWNER]=col[OWNER]
            obj.name='换绑_'+prev.get('hur_source',prev.name);obj.parent=None;obj.matrix_world=prev.matrix_world.copy()
            if obj.modifiers:raise ValueError('预览网格存在修改器。请先应用修改器，再生成绑定。')
            rows=[]
            for v in obj.data.vertices:
                base=defaultdict(float)
                for g in v.groups:
                    n=obj.vertex_groups[g.group].name
                    if n in mapping:base[mapping[n]]+=g.weight
                total=sum(base.values())
                if not total:raise ValueError(f'{obj.name} 顶点 {v.index} 没有映射权重。')
                base={n:w/total for n,w in base.items()}
                votes=defaultdict(float)
                for n,w in base.items():votes[region(n,rr)]+=w
                dw,coverage=donor.sample(obj.matrix_world@v.co,votes,max_distance) if donor else ({},0)
                for n in list(dw):
                    reg=region(n,rr)
                    if is_finger(n) and reg[-1:] in rigid_sides:
                        hand=rr.get('hand_'+reg[-1])
                        if hand:dw[hand]=dw.get(hand,0)+dw.pop(n)
                shoulder_factor=max((max(0,1-(obj.matrix_world@v.co-point).length/shoulder_radius) for point in shoulder_points),default=0) if shoulder_radius else 0
                local_mix=p.donor_mix+(max(p.donor_mix,p.shoulder_mix)-p.donor_mix)*shoulder_factor
                mix=local_mix*coverage if dw else 0
                row=defaultdict(float)
                for n,w in base.items():row[n]+=(1-mix)*w
                for n,w in dw.items():row[n]+=mix*w
                rows.append(dict(row))
            rows=smooth_weights(obj,rows,p.smooth_steps);write_weights(obj,rows,p.max_influences)
            for group in obj.vertex_groups:
                if group.name in rig.data.bones:rig.data.bones[group.name].use_deform=True
            world=obj.matrix_world.copy();obj.parent=rig;obj.matrix_parent_inverse=rig.matrix_world.inverted();obj.matrix_world=world
            mod=obj.modifiers.new('UE 换绑','ARMATURE');mod.object=rig;mod.use_deform_preserve_volume=False
            obj.hide_render=False;created.append(obj)
        if not created:raise ValueError('预览集合中没有可绑定的网格。')
        p.result_collection=col;p.result_rig=rig;p.stage=3
        rig['hur_rigid_hands']=','.join(sorted(rigid_sides))
        rig['hur_mapping']=json.dumps(mapping,ensure_ascii=False)
        rig['hur_weight_settings']=weight_settings(p)
        p.message=f'已生成 {len(created)} 个换绑网格，目标骨骼 {len(rig.data.bones)} 根。'
        if rigid_sides:p.message+=' 缺少源手指映射的手部保持整体绑定。'
        show_stage(p,'RESULT');activate(context,created[0]);validate(p)
        if previous_collection:
            for o in previous_collection.objects:o.hide_set(True);o.hide_render=True
    except Exception:
        remove_owned(col);p.result_collection=previous_collection;p.result_rig=previous_rig;p.stage=2;raise


def compare_skeleton(rig,target,add_root,positions=None):
    expected=set(target.data.bones.keys())
    new_root=add_root and not has_root(target)
    if new_root:expected.add('root')
    errors=[]
    if set(rig.data.bones.keys())!=expected:errors.append('骨骼集合与模板不一致')
    for b in target.data.bones:
        actual=rig.data.bones.get(b.name)
        if not actual:continue
        parent=b.parent.name if b.parent else ('root' if new_root else None)
        if (actual.parent.name if actual.parent else None)!=parent:errors.append(b.name+' 父级变化')
        reference=b.matrix_local.copy()
        if positions is not None:reference.translation=target.matrix_world.inverted()@positions[b.name]
        if max(abs(reference[i][j]-actual.matrix_local[i][j]) for i in range(4) for j in range(4))>1e-4:
            errors.append(b.name+' 参考姿势变化')
    if max(abs(rig.matrix_world[i][j]-target.matrix_world[i][j]) for i in range(4) for j in range(4))>1e-5:
        errors.append('结果骨架对象变换与目标不一致')
    return errors


def weight_settings(p):
    return json.dumps([p.weight_method,p.donor_mix,p.transfer_distance,p.smooth_steps,p.max_influences,p.shoulder_mix])


def validate(p):
    if not p.result_collection or not p.result_rig:raise ValueError('请先生成绑定结果。')
    check_preview(p)
    _,dst=inputs(p);rig=p.result_rig
    if rig.get('hur_weight_settings')!=weight_settings(p):
        raise ValueError('权重参数已变化，请重新生成绑定。手工绘制结果可直接重新检查。')
    errors=compare_skeleton(rig,dst,p.add_root,fitted_positions(p))
    roots=[b.name for b in rig.data.bones if not b.parent]
    if len(roots)!=1:errors.append('存在多个根骨骼，请补回 root 后重新生成。')
    unweighted=0;unnormalized=0;excess=0;verts=0;triangles=0;max_inf=0;unknown=set()
    for obj in p.result_collection.objects:
        if obj.type!='MESH':continue
        mods=[m for m in obj.modifiers if m.type=='ARMATURE']
        if len(mods)!=1 or mods[0].object!=rig or not mods[0].show_viewport:errors.append(obj.name+' 骨架修改器错误')
        if any(m.type!='ARMATURE' for m in obj.modifiers):errors.append(obj.name+' 还有未应用的修改器')
        obj.data.calc_loop_triangles();triangles+=len(obj.data.loop_triangles)
        for v in obj.data.vertices:
            verts+=1
            if not all(math.isfinite(x) for x in v.co):errors.append(obj.name+' 顶点坐标无效');break
            groups=[]
            for g in v.groups:
                if g.weight<=1e-8:continue
                n=obj.vertex_groups[g.group].name
                if n not in rig.data.bones:unknown.add(n)
                elif not rig.data.bones[n].use_deform:unknown.add(n+'（未启用变形）')
                else:groups.append(g.weight)
            total=sum(groups);max_inf=max(max_inf,len(groups))
            unweighted+=total<1e-7;unnormalized+=abs(total-1)>.0001;excess+=len(groups)>p.max_influences
    if not verts:errors.append('结果没有网格顶点')
    if unweighted:errors.append(f'{unweighted} 个顶点未赋权')
    if unnormalized:errors.append(f'{unnormalized} 个顶点权重未归一化')
    if excess:errors.append(f'{excess} 个顶点超过影响骨骼上限')
    if unknown:errors.append('无效权重组：'+','.join(sorted(unknown)))
    from . import geometry
    mesh_health=[geometry.public(geometry.scan(o,p)) for o in p.result_collection.objects if o.type=='MESH']
    if any(r['degenerate_faces'] or r['duplicate_faces'] for r in mesh_health):errors.append('存在退化面或重复面，请先运行网格检测与修复')
    report={'valid':not errors,'errors':errors,'vertices':verts,'triangles':triangles,'bones':len(rig.data.bones),
            'roots':roots,'unweighted':unweighted,'unnormalized':unnormalized,'max_influences':max_inf,
            'rigid_hands':rig.get('hur_rigid_hands',''),'requires_separate_skeleton':bool(dst.get('hur_requires_separate_skeleton')),'ue_runtime_tested':False,'mesh_health':mesh_health}
    if p.fit_mode=='POSE' and p.preview_collection.get('hur_pose_alignment'):
        report['pose_alignment']=json.loads(p.preview_collection['hur_pose_alignment'])
        report['translation_retargeting_required']=p.pose_fit_reference
    p.report=json.dumps(report,ensure_ascii=False,indent=2)
    p.stage=4 if not errors else 3
    if errors:raise ValueError('检查未通过：'+'；'.join(errors[:5]))
    p.message=f'检查通过：{verts} 顶点，{len(rig.data.bones)} 根骨骼，单根骨架；仍需 UE 实测动画。'
    if p.fit_mode=='POSE' and p.pose_fit_reference:p.message+=' 参考位置已适配体型，UE 必须配置位移重定向。'
    suspects=sum(r['suspect_folds'] for r in mesh_health)
    if suspects:p.message+=f' 另有 {suspects} 个疑似翻折面需人工检查。'
    return report


POSES={
    'REST':[], 'ARMS':[('clavicle_l',(0,1,0),-18),('clavicle_r',(0,1,0),18),('upperarm_l',(0,1,0),-47),('upperarm_r',(0,1,0),47)],
    'ARMS_ISOLATED':[('upperarm_l',(0,1,0),-65),('upperarm_r',(0,1,0),65)],
    'ELBOWS':[('lowerarm_l',(1,0,0),-80),('lowerarm_r',(1,0,0),-80)],
    'KNEES':[('thigh_l',(1,0,0),-45),('thigh_r',(1,0,0),-45),('calf_l',(1,0,0),90),('calf_r',(1,0,0),90)],
    'HEAD':[('head',(0,0,1),40)],
}


def pose(context,p,key):
    if not p.result_rig:raise ValueError('请先生成绑定结果。')
    rig=p.result_rig
    if rig.animation_data and (rig.animation_data.action or rig.animation_data.nla_tracks):
        raise ValueError('结果骨架已有动画，请先在副本上解除动画再使用测试姿势。')
    rr=roles(rig)
    if not p.pose_snapshot:
        p.pose_snapshot=json.dumps({pb.name:[list(row) for row in pb.matrix_basis] for pb in rig.pose.bones})
    for pb in rig.pose.bones:pb.matrix_basis=Matrix.Identity(4)
    missing=[]
    up,front=anatomical_basis(rig)
    basis=frame(Vector(),up,front).to_3x3()
    # Canonical anatomical axes: lateral, front, up (all in rig's world orientation).
    lateral=up.cross(front).normalized()
    for role,axis,degrees in POSES[key]:
        name=rr.get(role)
        if not name:missing.append(role);continue
        pb=rig.pose.bones[name]
        world_axis=lateral*axis[0]-front*axis[1]+up*axis[2]
        local_axis=(rig.matrix_world@pb.bone.matrix_local).to_quaternion().inverted()@world_axis
        pb.rotation_mode='QUATERNION';pb.rotation_quaternion=Quaternion(local_axis,math.radians(degrees))
    context.view_layer.update()
    p.message='测试姿势已应用。导出始终使用参考姿势副本。'+(' 未识别：'+','.join(missing) if missing else '')


def restore_pose(p):
    if p.result_rig and p.pose_snapshot:
        snapshot=json.loads(p.pose_snapshot)
        for n,rows in snapshot.items():
            if n in p.result_rig.pose.bones:p.result_rig.pose.bones[n].matrix_basis=Matrix(rows)
        p.pose_snapshot=''
