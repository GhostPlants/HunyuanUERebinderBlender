"""Pose-only fitting: rigid segment rotations, unchanged source joint lengths.

Optional reference fitting moves joint positions only, keeping UE orientations.
Landmarks come from the source rig, not automatic surface anatomy detection.
"""
from collections import deque
from mathutils import Matrix, Vector


def solve(src, dst, mapping):
    from . import core
    sup, sf = core.anatomical_basis(src, True)
    tup, tf = core.anatomical_basis(dst)
    sr, tr = core.roles(src), core.roles(dst)
    if not all(r in sr and r in tr for r in ('pelvis', 'head', 'upperarm_l', 'upperarm_r')):
        raise ValueError('仅匹配姿势需要可识别的骨盆、头部和左右上臂。')
    sh = lambda n: src.matrix_world @ src.pose.bones[n].head
    th = lambda n: dst.matrix_world @ dst.data.bones[n].head_local
    global_q = (core.frame(Vector(), tup, tf).to_quaternion() @
                core.frame(Vector(), sup, sf).to_quaternion().inverted())
    base = (Matrix.Translation(th(tr['pelvis'])) @ global_q.to_matrix().to_4x4() @
            Matrix.Translation(-sh(sr['pelvis'])))
    transforms = {}
    # Parent transforms place each next joint, so target lengths never enter the solve.
    for b in sorted(src.data.bones, key=lambda b: len(b.parent_recursive)):
        parent = transforms[b.parent.name] if b.parent else base
        a = sh(b.name)
        position = parent @ a
        rotation = parent.to_quaternion()
        target = mapping.get(b.name)
        if target:
            queue = deque(b.children)
            child = None
            while queue:
                candidate = queue.popleft()
                t = mapping.get(candidate.name)
                if t and t != target and dst.data.bones[target] in dst.data.bones[t].parent_recursive:
                    child = candidate.name
                    break
                queue.extend(candidate.children)
            if child:
                u, v = sh(child) - a, th(mapping[child]) - th(target)
            else:
                u = v = None
                # Palm direction from fingers; FBX display tails are not anatomical axes.
                side = next((s for s in ('l', 'r') if tr.get('hand_' + s) == target), None)
                tip = tr.get('middle_03_' + side) if side else None
                if tip:
                    u = src.matrix_world @ src.pose.bones[b.name].tail - a
                    v = th(tip) - th(target)
                if target == tr.get('head'):
                    rotation = global_q
            if u is not None and u.length > 1e-7 and v.length > 1e-7:
                rotation = (core.frame(Vector(), v, tf).to_quaternion() @
                            core.frame(Vector(), u, sf).to_quaternion().inverted())
        transforms[b.name] = (Matrix.Translation(position) @ rotation.to_matrix().to_4x4() @
                              Matrix.Translation(-a))
    rows = []
    for s, t in mapping.items():
        position = transforms[s] @ sh(s)
        rows.append({'source': s, 'target': t, 'posed_source_joint': list(position),
                     'target_joint': list(th(t)), 'distance': (position - th(t)).length})
    rows.sort(key=lambda r: r['distance'], reverse=True)
    return {s: transforms[s] for s in mapping}, rows


def reference_positions(src, dst, mapping):
    """World joint positions, with unmapped joints interpolated along target chains."""
    from . import core
    if dst.get('hur_custom_reference') or dst.get('hur_requires_separate_skeleton'):
        raise ValueError('骨架贴合模型请使用原始 UE 目标骨架，不要选择旧的独立体态参考骨架。')
    _, rows = solve(src, dst, mapping)
    anchors = {}
    for row in rows:
        name = row['target']
        if name in anchors:
            raise ValueError('骨架贴合模型需要一对一映射，多个源关节映射到：' + name)
        anchors[name] = Vector(row['posed_source_joint'])
    head = lambda n: dst.matrix_world @ dst.data.bones[n].head_local
    _, front = core.anatomical_basis(dst)
    positions = dict(anchors)
    frames = {}
    for name, position in anchors.items():
        bone = dst.data.bones[name]
        descendants = [b for b in dst.data.bones if b.name in anchors and bone in b.parent_recursive]
        if descendants:
            child = min(descendants, key=lambda b: len(b.parent_recursive)).name
            old_length = (head(child) - head(name)).length
            ratio = (anchors[child] - position).length / max(old_length, 1e-7)
            frames[name] = core.fit_segment(head(name), head(child), position, anchors[child], front, front, ratio)
        else:
            frames[name] = Matrix.Translation(position - head(name))
    for bone in dst.data.bones:
        if bone.name in positions:
            continue
        ancestor = next((b.name for b in bone.parent_recursive if b.name in frames), None)
        positions[bone.name] = frames[ancestor] @ head(bone.name) if ancestor else head(bone.name)
    # IK leaves must follow their anatomical landmarks rather than a root offset.
    roles = core.roles(dst)
    for helper, role in [('ik_foot_l','foot_l'), ('ik_foot_r','foot_r'),
                         ('ik_hand_l','hand_l'), ('ik_hand_r','hand_r'), ('ik_hand_gun','hand_r')]:
        target = roles.get(role)
        if helper in positions and helper not in anchors and target in anchors:
            positions[helper] = anchors[target] + head(helper) - head(target)
    return positions


def apply_reference(context, rig, positions):
    """Translate whole edit bones: never aim/roll them at child joints."""
    import bpy
    from . import core
    core.activate(context, rig)
    inv = rig.matrix_world.inverted()
    bpy.ops.object.mode_set(mode='EDIT')
    try:
        for b in rig.data.edit_bones:
            b.use_connect = False
        for b in rig.data.edit_bones:
            if b.name in positions:
                delta = inv @ positions[b.name] - b.head
                b.translate(delta)
    finally:
        bpy.ops.object.mode_set(mode='OBJECT')
    rig['hur_translation_retargeting_required'] = True
    rig['hur_reference_rotations_preserved'] = True


def report(src, dst, mapping, unit, fit_reference=False):
    _, rows = solve(src, dst, mapping)
    for row in rows:
        row['distance_m'] = row.pop('distance') * unit
    maximum = max((r['distance_m'] for r in rows), default=0)
    if fit_reference:
        positions = reference_positions(src, dst, mapping)
        for row in rows:
            row['original_template_gap_m'] = row['distance_m']
            row['target_joint'] = list(positions[row['target']])
            row['distance_m'] = (Vector(row['posed_source_joint']) - positions[row['target']]).length * unit
    return {'mode': 'POSE', 'target_reference_unchanged': not fit_reference,
            'reference_rotations_preserved': True,
            'translation_retargeting_required': fit_reference,
            'source_lengths_preserved': True, 'anchor': 'pelvis',
            'max_original_template_gap_m': maximum,
            'max_joint_gap_m': max((r['distance_m'] for r in rows), default=0),
            'joints': rows,
            'note': ('骨架关节适配源关节，保留 UE 参考旋转；共享动画需设置 UE 位移重定向并实测 IK。'
                     if fit_reference else '仅匹配姿势不保证关节重合；刷权重不能消除较大的关节位置偏差。')}
