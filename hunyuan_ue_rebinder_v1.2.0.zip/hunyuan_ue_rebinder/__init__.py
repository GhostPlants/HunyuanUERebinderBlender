bl_info = {
    'name':'混元 → UE 骨架换绑助手',
    'author':'Codex', 'version':(1,2,0), 'blender':(4,2,0),
    'location':'3D Viewport > N 面板 > UE 换绑',
    'description':'选择 UE 和混元骨架，分步对齐、换绑、检查并导出 FBX',
    'category':'Rigging',
}

import bpy
import json
import traceback
from pathlib import Path
from bpy.props import (PointerProperty,StringProperty,CollectionProperty,BoolProperty,IntProperty,FloatProperty,EnumProperty)
from bpy.types import PropertyGroup,Operator,Panel,UIList
from bpy_extras.io_utils import ExportHelper,ImportHelper
from . import core,exporter,geometry,proportions


def object_poll(self,obj):return obj.type in {'ARMATURE','EMPTY'} and not obj.get(core.OWNER)
def mesh_poll(self,obj):return obj.type=='MESH' and not obj.get(core.OWNER)
def inputs_changed(self,context):
    self.stage=0;self.message='输入已变化，请重新检查输入。';self.report=''
def fit_changed(self,context):
    if self.stage>=2:self.stage=1
    self.report=''
def mapping_changed(self,context):
    if context and hasattr(context.scene,'hur_settings'):
        p=context.scene.hur_settings
        if p.stage>=2:p.stage=1
        p.report=''
def weights_changed(self,context):
    if self.stage>=3:self.stage=2
    self.report=''


class HUR_Mapping(PropertyGroup):
    source:StringProperty()
    target:StringProperty(update=mapping_changed)
    weighted:BoolProperty()


class HUR_Mesh(PropertyGroup):
    obj:PointerProperty(type=bpy.types.Object)
    enabled:BoolProperty(default=True,update=mapping_changed)


class HUR_Visibility(PropertyGroup):
    obj:PointerProperty(type=bpy.types.Object)
    hidden:BoolProperty()


class HUR_Settings(PropertyGroup):
    target:PointerProperty(name='UE 骨架',description='目标 UE 骨架，或仅包含一套骨架的外层对象（如 SKM_Manny_Simple）',type=bpy.types.Object,poll=object_poll,update=inputs_changed)
    source:PointerProperty(name='混元骨架',description='已有蒙皮的混元角色骨架；关联网格自动识别',type=bpy.types.Object,poll=object_poll,update=inputs_changed)
    source_rig:PointerProperty(type=bpy.types.Object)
    target_rig:PointerProperty(type=bpy.types.Object)
    donor:PointerProperty(name='UE 参考网格',description='自动选择 LOD0；可选。只提供 UE 骨架也能使用原权重换绑',type=bpy.types.Object,poll=mesh_poll,update=fit_changed)
    meshes:CollectionProperty(type=HUR_Mesh)
    mapping:CollectionProperty(type=HUR_Mapping)
    mapping_index:IntProperty()
    visibility:CollectionProperty(type=HUR_Visibility)
    only_weighted:BoolProperty(name='只看有权重的骨骼',default=True)
    fit_mode:EnumProperty(name='对齐方式',items=[('AUTO','自动适配目标参考姿势','根据骨骼映射的关节位置调整网格；保持 UE 骨架参考变换'),('ALIGNED','已手工对齐，保持网格','仅烘焙源当前外形，不做自动体型适配')],default='AUTO',update=fit_changed)
    head_size:FloatProperty(name='头部比例',description='相对整体尺寸适配比例；改变后重新生成预览',default=.95,min=.5,max=1.5,update=fit_changed)
    head_anchor:EnumProperty(name='头部定位',items=[('JOINT','按头部关节定位','保留头部与颈部的关节关系，发髻和帽子可以高于参考网格'),('HEIGHT','按模型顶端对齐（旧版）','对齐模型最高点；高发髻或帽子可能把头部压低')],default='JOINT',update=fit_changed)
    hand_size:FloatProperty(name='手部粗细',default=.88,min=.5,max=1.5,update=fit_changed)
    add_root:BoolProperty(name='缺失时补回 root',description='仅当目标没有名为 root 的骨骼时添加，将原顶层骨骼接到 root；已有 root 时不重复添加',default=True,update=fit_changed)
    bake_shapes:BoolProperty(name='烘焙当前形态（不保留形态键）',description='允许将源 Shape Keys 的当前外形固化到新网格；原模型保留',default=False,update=fit_changed)
    hide_inputs:BoolProperty(name='预览时隐藏输入',default=True)
    stabilize_fit:BoolProperty(name='拟合防翻折（保留局部细节）',default=True,update=fit_changed)
    fit_stability:FloatProperty(name='拟合稳定强度',description='约束源网格局部边形状，减少关节权重过渡导致的翻折；提高会略改变贴合程度',default=.65,min=0,max=1,update=fit_changed)
    mesh_scope:EnumProperty(name='检测对象',items=[('SOURCE','原模型（只检测）',''),('PREVIEW','对齐预览',''),('RESULT','换绑结果','')],default='PREVIEW')
    mesh_epsilon:FloatProperty(name='退化面容差（米）',default=.000001,min=.00000001,max=.0001,precision=8)
    island_faces:IntProperty(name='小岛最大面数',default=80,min=1,max=500)
    island_area:FloatProperty(name='小岛最大面积（平方米）',default=.0001,min=.0000001,max=.01,precision=7)
    remove_islands:BoolProperty(name='删除检测到的小岛（可能是装饰）',default=False)
    repair_folds:BoolProperty(name='修复时稳定局部翻折',default=True)
    recalc_normals:BoolProperty(name='重算法线方向',default=False,description='开放的衣服表面不一定需要重算法线；不用于消除几何穿插')
    mesh_report:StringProperty()
    weight_method:EnumProperty(name='权重方式',items=[('HYBRID','原权重 + UE 参考权重','按身体区域混合 UE 网格权重；没有参考网格时使用原权重'),('SOURCE','仅迁移原权重','按骨骼映射迁移，不使用表面转移')],default='HYBRID',update=weights_changed)
    donor_mix:FloatProperty(name='UE 权重比例',default=.75,min=0,max=1,subtype='FACTOR',update=weights_changed)
    shoulder_mix:FloatProperty(name='肩部 UE 权重比例',description='肩关节附近渐进提高参考权重比例，减少胸部和上臂权重互相拖拽',default=.9,min=0,max=1,subtype='FACTOR',update=weights_changed)
    transfer_distance:FloatProperty(name='最大转移距离（米）',description='超过距离时保留原映射权重；与场景单位自动换算',default=.20,min=.001,max=2,precision=3,update=weights_changed)
    smooth_steps:IntProperty(name='权重平滑次数',default=6,min=0,max=20,update=weights_changed)
    max_influences:IntProperty(name='每顶点骨骼上限',default=8,min=1,max=12,update=weights_changed)
    embed_textures:BoolProperty(name='FBX 内嵌贴图',default=True)
    preview_collection:PointerProperty(type=bpy.types.Collection)
    preview_rig:PointerProperty(type=bpy.types.Object)
    result_collection:PointerProperty(type=bpy.types.Collection)
    result_rig:PointerProperty(type=bpy.types.Object)
    stage:IntProperty(default=0)
    input_stamp:StringProperty()
    message:StringProperty(default='先选择两套骨架，再点击「检查输入」。')
    warnings:StringProperty()
    report:StringProperty()
    last_export:StringProperty(subtype='FILE_PATH')
    pose_snapshot:StringProperty()


class HUR_Operator:
    def execute(self,context):
        p=context.scene.hur_settings
        try:
            self.run(context,p)
            self.report({'INFO'},p.message[:220])
            return {'FINISHED'}
        except Exception as exc:
            traceback.print_exc()
            p.message=str(exc)
            self.report({'ERROR'},str(exc)[:500])
            return {'CANCELLED'}


class HUR_OT_inspect(HUR_Operator,Operator):
    bl_idname='hur.inspect';bl_label='1. 检查输入并识别网格';bl_options={'REGISTER','UNDO'}
    def run(self,context,p):
        core.restore_inputs(p);core.inspect(context,p)


class HUR_OT_automap(HUR_Operator,Operator):
    bl_idname='hur.automap';bl_label='重新自动匹配';bl_options={'REGISTER','UNDO'}
    def run(self,context,p):
        src,dst=core.inputs(p);matches=core.auto_map(src,dst)
        for row in p.mapping:row.target=matches.get(row.source,'')
        p.message='已重新匹配。请检查红色的未映射骨骼。'


class HUR_OT_check_mapping(HUR_Operator,Operator):
    bl_idname='hur.check_mapping';bl_label='2. 检查映射';bl_options={'REGISTER','UNDO'}
    def run(self,context,p):
        core.check_mapping(p);p.message='所有参与蒙皮的源骨骼均已映射，可以生成对齐预览。'


class HUR_OT_proportions(HUR_Operator,Operator):
    bl_idname='hur.proportions';bl_label='保留体态：创建独立参考骨架';bl_options={'REGISTER','UNDO'}
    def run(self,context,p):proportions.create_reference(context,p)


class HUR_OT_preview(HUR_Operator,Operator):
    bl_idname='hur.preview';bl_label='3. 生成 / 更新对齐预览';bl_options={'REGISTER','UNDO'}
    def run(self,context,p):
        core.restore_pose(p);core.preview(context,p)


class HUR_OT_bind(HUR_Operator,Operator):
    bl_idname='hur.bind';bl_label='4. 生成换绑模型';bl_options={'REGISTER','UNDO'}
    def run(self,context,p):
        core.restore_pose(p);core.bind(context,p)


class HUR_OT_validate(HUR_Operator,Operator):
    bl_idname='hur.validate';bl_label='5. 检查骨架和权重';bl_options={'REGISTER','UNDO'}
    def run(self,context,p):core.validate(p)


class HUR_OT_pose(HUR_Operator,Operator):
    bl_idname='hur.pose';bl_label='应用测试姿势';bl_options={'REGISTER','UNDO'}
    kind:EnumProperty(items=[('REST','参考姿势',''),('ARMS','抬臂（含锁骨）',''),('ARMS_ISOLATED','只转上臂（压力测试）',''),('ELBOWS','弯肘',''),('KNEES','屈膝',''),('HEAD','转头','')])
    def run(self,context,p):core.pose(context,p,self.kind)


class HUR_OT_restore_pose(HUR_Operator,Operator):
    bl_idname='hur.restore_pose';bl_label='恢复测试前姿势';bl_options={'REGISTER','UNDO'}
    def run(self,context,p):core.restore_pose(p);p.message='已恢复测试前姿势。'


class HUR_OT_show(HUR_Operator,Operator):
    bl_idname='hur.show';bl_label='显示模型';bl_options={'REGISTER','UNDO'}
    kind:EnumProperty(items=[('PREVIEW','显示对齐预览',''),('RESULT','显示换绑结果',''),('INPUT','恢复输入可见性','')])
    def run(self,context,p):
        if self.kind=='INPUT':core.restore_inputs(p);p.message='已恢复输入模型原来的可见状态。';return
        col=p.preview_collection if self.kind=='PREVIEW' else p.result_collection
        if not col:raise ValueError('尚未生成此步骤的模型。')
        core.show_stage(p,self.kind)
        mesh=next((o for o in col.objects if o.type=='MESH'),None)
        if mesh:core.activate(context,mesh)
        if self.kind=='PREVIEW':p.stage=2
        p.message='已显示 '+col.name


class HUR_OT_weight_paint(HUR_Operator,Operator):
    bl_idname='hur.weight_paint';bl_label='手动修正权重';bl_options={'REGISTER','UNDO'}
    def run(self,context,p):
        if not p.result_collection:raise ValueError('请先生成换绑模型。')
        obj=context.object if context.object in list(p.result_collection.objects) and context.object.type=='MESH' else next(o for o in p.result_collection.objects if o.type=='MESH')
        core.activate(context,obj);bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
        p.stage=3;p.message='已进入权重绘制。修正后重新检查，再导出。'


class HUR_OT_export(HUR_Operator,Operator,ExportHelper):
    bl_idname='hur.export_fbx';bl_label='6. 导出 FBX';filename_ext='.fbx'
    filter_glob:StringProperty(default='*.fbx',options={'HIDDEN'})
    def invoke(self,context,event):
        if not self.filepath:self.filepath=bpy.path.abspath('//Hunyuan_UE_Rebound.fbx')
        return ExportHelper.invoke(self,context,event)
    def run(self,context,p):exporter.export_fbx(context,p,self.filepath)


class HUR_OT_mesh_scan(HUR_Operator,Operator):
    bl_idname='hur.mesh_scan';bl_label='检测网格问题';bl_options={'REGISTER','UNDO'}
    def run(self,context,p):geometry.inspect_meshes(context,p)


class HUR_OT_mesh_repair(HUR_Operator,Operator):
    bl_idname='hur.mesh_repair';bl_label='修复副本网格';bl_options={'REGISTER','UNDO'}
    def run(self,context,p):geometry.repair_meshes(context,p)


class HUR_OT_mesh_select(HUR_Operator,Operator):
    bl_idname='hur.mesh_select';bl_label='选中疑似问题面';bl_options={'REGISTER','UNDO'}
    def run(self,context,p):geometry.select_problems(context,p)


class HUR_OT_save_blend(HUR_Operator,Operator,ExportHelper):
    bl_idname='hur.save_blend';bl_label='另存 Blender 副本';filename_ext='.blend'
    filter_glob:StringProperty(default='*.blend',options={'HIDDEN'})
    def invoke(self,context,event):
        if not self.filepath:self.filepath=bpy.path.abspath('//Hunyuan_UE_Rebound.blend')
        return ExportHelper.invoke(self,context,event)
    def run(self,context,p):
        filepath=str(Path(self.filepath).with_suffix('.blend'))
        if bpy.data.filepath and Path(filepath).resolve()==Path(bpy.data.filepath).resolve():
            raise ValueError('请选择新的 .blend 文件名，以保留当前源文件。')
        bpy.ops.wm.save_as_mainfile(filepath=filepath,copy=True)
        p.message='已另存 Blender 副本。'


class HUR_OT_save_mapping(HUR_Operator,Operator,ExportHelper):
    bl_idname='hur.save_mapping';bl_label='保存映射';filename_ext='.json'
    filter_glob:StringProperty(default='*.json',options={'HIDDEN'})
    def run(self,context,p):
        core.check_mapping(p)
        data={'schema':1,'mapping':{r.source:r.target for r in p.mapping}}
        Path(self.filepath).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
        p.message='映射预设已保存。'


class HUR_OT_load_mapping(HUR_Operator,Operator,ImportHelper):
    bl_idname='hur.load_mapping';bl_label='加载映射';filename_ext='.json'
    filter_glob:StringProperty(default='*.json',options={'HIDDEN'})
    def run(self,context,p):
        data=json.loads(Path(self.filepath).read_text(encoding='utf8'))
        if data.get('schema')!=1 or not isinstance(data.get('mapping'),dict):raise ValueError('不是本工具的映射预设。')
        _,dst=core.inputs(p)
        if not p.mapping:raise ValueError('请先检查输入。')
        invalid=[v for k,v in data['mapping'].items() if not isinstance(k,str) or not isinstance(v,str) or (v and v not in dst.data.bones)]
        if invalid:raise ValueError('预设包含当前目标中不存在的骨骼：'+str(invalid[:8]))
        for row in p.mapping:
            if row.source in data['mapping']:row.target=data['mapping'][row.source]
        p.message='已加载预设，请检查映射后继续。'


class HUR_UL_mapping(UIList):
    def draw_item(self,context,layout,data,item,icon,active_data,active_propname,index):
        p=context.scene.hur_settings
        row=layout.row(align=True)
        row.alert=item.weighted and (not item.target or not p.target_rig or item.target not in p.target_rig.data.bones)
        split=row.split(factor=.46);split.label(text=item.source,icon='BONE_DATA')
        if p.target_rig:split.prop_search(item,'target',p.target_rig.data,'bones',text='')
    def filter_items(self,context,data,propname):
        items=getattr(data,propname);p=context.scene.hur_settings
        flags=[self.bitflag_filter_item if not p.only_weighted or i.weighted else 0 for i in items]
        if self.filter_name:
            for j,i in enumerate(items):
                if self.filter_name.lower() not in (i.source+' '+i.target).lower():flags[j]=0
        return flags,[]


def lines(layout,text,width=34):
    for paragraph in text.splitlines():
        for start in range(0,len(paragraph),width):layout.label(text=paragraph[start:start+width])


class HUR_PT_main(Panel):
    bl_label='混元 → UE 骨架换绑';bl_idname='HUR_PT_main'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='UE 换绑'
    def draw(self,context):
        p=context.scene.hur_settings;l=self.layout
        l.label(text=['① 选择输入','② 映射与对齐','③ 确认预览','④ 检查结果','⑤ 可以导出','⑥ 已导出'][max(0,min(5,p.stage))],icon='ARMATURE_DATA')
        box=l.box();lines(box,p.message)


class HUR_PT_inputs(Panel):
    bl_label='1 · 输入两套骨架';bl_parent_id='HUR_PT_main'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='UE 换绑'
    def draw(self,context):
        p=context.scene.hur_settings;l=self.layout
        l.prop(p,'target');l.prop(p,'source');l.operator('hur.inspect',icon='VIEWZOOM')
        for item in p.meshes:
            if item.obj:l.prop(item,'enabled',text=item.obj.name)
        if p.stage:
            l.prop(p,'donor');l.prop(p,'bake_shapes');l.prop(p,'hide_inputs')
        if p.warnings:lines(l.box(),p.warnings)


class HUR_PT_mapping(Panel):
    bl_label='2 · 骨骼对应关系';bl_parent_id='HUR_PT_main'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='UE 换绑'
    def draw(self,context):
        p=context.scene.hur_settings;l=self.layout;l.enabled=p.stage>=1
        l.prop(p,'only_weighted')
        l.template_list('HUR_UL_mapping','',p,'mapping',p,'mapping_index',rows=8)
        l.operator('hur.automap',icon='FILE_REFRESH')
        row=l.row(align=True);row.operator('hur.load_mapping',icon='IMPORT');row.operator('hur.save_mapping',icon='EXPORT')
        l.operator('hur.check_mapping',icon='CHECKMARK')


class HUR_PT_preview(Panel):
    bl_label='3 · 对齐预览';bl_parent_id='HUR_PT_main'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='UE 换绑'
    def draw(self,context):
        p=context.scene.hur_settings;l=self.layout;l.enabled=p.stage>=1
        l.prop(p,'fit_mode');l.prop(p,'head_anchor');l.prop(p,'head_size');l.prop(p,'hand_size');l.prop(p,'add_root')
        l.operator('hur.proportions',icon='ARMATURE_DATA')
        lines(l,'保留体态会调整目标副本的参考关节，UE 需独立 Skeleton 和动画重定向。源当前姿势将作为参考姿势。')
        l.prop(p,'stabilize_fit')
        if p.stabilize_fit:l.prop(p,'fit_stability')
        l.operator('hur.preview',icon='MOD_ARMATURE')
        lines(l,'生成预览后，可编辑预览网格。重新生成会替换旧预览，请先另存需要保留的修改。')
        row=l.row(align=True)
        row.operator('hur.show',text='显示预览').kind='PREVIEW';row.operator('hur.show',text='恢复输入').kind='INPUT'


class HUR_PT_geometry(Panel):
    bl_label='3.5 · 网格检测与修复';bl_parent_id='HUR_PT_main'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='UE 换绑'
    def draw(self,context):
        p=context.scene.hur_settings;l=self.layout;l.enabled=p.stage>=1
        l.prop(p,'mesh_scope');l.prop(p,'mesh_epsilon')
        row=l.row(align=True);row.prop(p,'island_faces');row.prop(p,'island_area')
        l.operator('hur.mesh_scan',icon='VIEWZOOM');l.operator('hur.mesh_select',icon='FACESEL')
        l.prop(p,'repair_folds');l.prop(p,'remove_islands');l.prop(p,'recalc_normals')
        row=l.row();row.enabled=p.mesh_scope!='SOURCE';row.operator('hur.mesh_repair',icon='MOD_SMOOTH')
        lines(l,'默认保留衣服、护甲小岛，不做全局焊接。翻折为局部方向检测，不等于完整穿插检测。')
        if p.mesh_report:
            for r in json.loads(p.mesh_report):
                row=r.get('after',r)
                l.label(text=row['object'])
                l.label(text=f"退化 {row['degenerate_faces']} · 小岛 {row['small_islands']} · 疑似翻折 {row['suspect_folds']}")


class HUR_PT_bind(Panel):
    bl_label='4 · 生成换绑模型';bl_parent_id='HUR_PT_main'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='UE 换绑'
    def draw(self,context):
        p=context.scene.hur_settings;l=self.layout;l.enabled=p.stage>=2
        l.prop(p,'weight_method')
        if p.weight_method=='HYBRID':l.prop(p,'donor_mix');l.prop(p,'shoulder_mix');l.prop(p,'transfer_distance')
        l.prop(p,'smooth_steps');l.prop(p,'max_influences')
        l.operator('hur.bind',icon='OUTLINER_OB_ARMATURE')
        lines(l,'没有独立手指映射时，手部整体绑定；保留目标手指骨骼。')


class HUR_PT_check(Panel):
    bl_label='5 · 检查与修正';bl_parent_id='HUR_PT_main'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='UE 换绑'
    def draw(self,context):
        p=context.scene.hur_settings;l=self.layout;l.enabled=p.stage>=3
        l.operator('hur.show',text='显示换绑结果',icon='HIDE_OFF').kind='RESULT'
        row=l.row(align=True)
        for key,text in [('REST','参考'),('ARMS','抬臂'),('ELBOWS','弯肘')]:row.operator('hur.pose',text=text).kind=key
        row=l.row(align=True)
        for key,text in [('KNEES','屈膝'),('HEAD','转头')]:row.operator('hur.pose',text=text).kind=key
        l.operator('hur.pose',text='只转上臂（压力测试）').kind='ARMS_ISOLATED'
        l.operator('hur.restore_pose');l.operator('hur.weight_paint',icon='WPAINT_HLT');l.operator('hur.validate',icon='CHECKMARK')
        if p.report:
            data=json.loads(p.report)
            l.label(text=f"{data['bones']} 骨骼 · {data['vertices']} 顶点")
            l.label(text=f"未赋权 {data['unweighted']} · 最大影响 {data['max_influences']}")
            if data['errors']:lines(l,'；'.join(data['errors']))


class HUR_PT_export(Panel):
    bl_label='6 · 导出';bl_parent_id='HUR_PT_main'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='UE 换绑'
    def draw(self,context):
        p=context.scene.hur_settings;l=self.layout;l.enabled=p.stage>=3
        l.prop(p,'embed_textures');l.operator('hur.export_fbx',icon='EXPORT');l.operator('hur.save_blend',icon='FILE_BLEND')
        lines(l,'导出前自动检查，使用参考姿势。导入 UE 时选择对应的目标 Skeleton，并检查实际动画。')
        if p.last_export:lines(l,p.last_export)


CLASSES=(HUR_Mapping,HUR_Mesh,HUR_Visibility,HUR_Settings,HUR_OT_inspect,HUR_OT_automap,HUR_OT_check_mapping,
    HUR_OT_proportions,HUR_OT_preview,HUR_OT_bind,HUR_OT_validate,HUR_OT_pose,HUR_OT_restore_pose,HUR_OT_show,HUR_OT_weight_paint,
    HUR_OT_export,HUR_OT_mesh_scan,HUR_OT_mesh_repair,HUR_OT_mesh_select,HUR_OT_save_blend,HUR_OT_save_mapping,HUR_OT_load_mapping,HUR_UL_mapping,
    HUR_PT_main,HUR_PT_inputs,HUR_PT_mapping,HUR_PT_preview,HUR_PT_geometry,HUR_PT_bind,HUR_PT_check,HUR_PT_export)


def register():
    for cls in CLASSES:bpy.utils.register_class(cls)
    bpy.types.Scene.hur_settings=PointerProperty(type=HUR_Settings)


def unregister():
    for scene in bpy.data.scenes:
        if hasattr(scene,'hur_settings'):
            core.restore_pose(scene.hur_settings);core.restore_inputs(scene.hur_settings)
    if hasattr(bpy.types.Scene,'hur_settings'):del bpy.types.Scene.hur_settings
    for cls in reversed(CLASSES):bpy.utils.unregister_class(cls)


if __name__=='__main__':register()
