"""Mesh diagnostics and conservative repair of owned previews/results.

Fold flags are local orientation heuristics, NOT a complete self-intersection test.
Differential fitting preserves source edge detail instead of smoothing the surface.
"""
import bpy,bmesh,json
import numpy as np
from mathutils import Vector
from . import core

REFERENCE='hur_source_position'
LINEAR=['hur_fit_row_'+str(i) for i in range(3)]
FLAG='hur_problem_face'


def store_reference(obj,points,linears):
    for name,values in [(REFERENCE,points)]+[(name,[a[i] for a in linears]) for i,name in enumerate(LINEAR)]:
        attr=obj.data.attributes.get(name) or obj.data.attributes.new(name,'FLOAT_VECTOR','POINT')
        attr.data.foreach_set('vector',np.asarray(values,dtype=np.float32).ravel())


def reference(obj):
    arrays=[]
    for name in [REFERENCE]+LINEAR:
        attr=obj.data.attributes.get(name)
        if not attr or attr.domain!='POINT' or attr.data_type!='FLOAT_VECTOR':return None
        a=np.empty(len(obj.data.vertices)*3,dtype=np.float64);attr.data.foreach_get('vector',a);arrays.append(a.reshape(-1,3))
    return arrays[0],np.stack(arrays[1:],axis=1)


def points_array(obj):
    a=np.empty(len(obj.data.vertices)*3,dtype=np.float64);obj.data.vertices.foreach_get('co',a)
    return a.reshape(-1,3)


def fold_metrics(obj,positions=None):
    ref=reference(obj)
    if ref is None:return {'available':False,'fold_faces':[],'stretch_faces':[]}
    source,linear=ref
    pos=points_array(obj) if positions is None else positions
    obj.data.calc_loop_triangles()
    if not obj.data.loop_triangles:return {'available':True,'fold_faces':[],'stretch_faces':[]}
    tri=np.array([t.vertices[:] for t in obj.data.loop_triangles],dtype=np.int32)
    a,b,c=tri.T
    matrices=(linear[a]+linear[b]+linear[c])/3
    u=np.einsum('nij,nj->ni',matrices,source[b]-source[a]);v=np.einsum('nij,nj->ni',matrices,source[c]-source[a])
    expected=np.cross(u,v);actual=np.cross(pos[b]-pos[a],pos[c]-pos[a])
    el=np.linalg.norm(expected,axis=1);al=np.linalg.norm(actual,axis=1)
    valid=(el>1e-14)&(al>1e-14)
    dot=np.sum(expected*actual,axis=1)/np.maximum(el*al,1e-30)
    folds=np.where(valid & (dot<-.05))[0]
    ratio=al/np.maximum(el,1e-30)
    stretches=np.where((el>1e-14)&((ratio<.08)|(ratio>5)))[0]
    polygon=np.array([t.polygon_index for t in obj.data.loop_triangles])
    return {'available':True,'fold_faces':sorted(set(polygon[folds].tolist())),
            'stretch_faces':sorted(set(polygon[stretches].tolist()))}


def stabilize(obj,strength=.65,iterations=160):
    """Solve screened differential coordinates; retain source detail and anchor to fit.

    A per-vertex blended affine fit can introduce large derivatives of its weights.
    Solve for positions whose edge differences follow the blended local transforms.
    Screening anchors preserve the target joint placement. No topology is changed.
    """
    ref=reference(obj)
    if ref is None:raise ValueError('此网格没有新版拟合参考数据，请重新生成对齐预览。')
    if strength<=0:return {'before':fold_metrics(obj),'after':fold_metrics(obj),'max_move':0}
    source,linear=ref;initial=points_array(obj)
    if not len(obj.data.edges):return {'before':fold_metrics(obj),'after':fold_metrics(obj),'max_move':0}
    edges=np.array([e.vertices[:] for e in obj.data.edges],dtype=np.int32);a,b=edges.T
    before=fold_metrics(obj,initial)
    vector=np.einsum('nij,nj->ni',(linear[a]+linear[b])*.5,source[b]-source[a])
    length=np.linalg.norm(vector,axis=1)
    median=max(1e-8,float(np.median(length)))
    w=np.clip(median/np.maximum(length,median*.25),.2,4)
    degree=np.zeros(len(initial));np.add.at(degree,a,w);np.add.at(degree,b,w)
    lam=(1-strength)*.15+.002
    anchor=np.maximum(degree,1)*lam
    rhs=initial*anchor[:,None]
    np.add.at(rhs,a,-vector*w[:,None]);np.add.at(rhs,b,vector*w[:,None])
    def apply(x):
        y=anchor[:,None]*x
        delta=(x[a]-x[b])*w[:,None]
        np.add.at(y,a,delta);np.add.at(y,b,-delta)
        return y
    # Jacobi-preconditioned conjugate gradients for three coordinate RHS at once.
    x=initial.copy();r=rhs-apply(x);diag=anchor+degree
    z=r/diag[:,None];direction=z.copy();rz=np.sum(r*z,axis=0)
    for _ in range(iterations):
        ad=apply(direction);alpha=rz/np.maximum(np.sum(direction*ad,axis=0),1e-30)
        x+=direction*alpha;r-=ad*alpha
        if np.max(np.abs(r))<median*1e-7:break
        z=r/diag[:,None];next_rz=np.sum(r*z,axis=0)
        direction=z+direction*(next_rz/np.maximum(rz,1e-30));rz=next_rz
    if not np.all(np.isfinite(x)):raise ValueError('拟合稳定求解失败，未修改网格。')
    after=fold_metrics(obj,x)
    # Never accept a fit with more local fold flags than the input.
    if len(after['fold_faces'])>len(before['fold_faces']):
        return {'before':before,'after':before,'max_move':0,'accepted':False}
    obj.data.vertices.foreach_set('co',x.astype(np.float32).ravel());obj.data.update()
    return {'before':before,'after':after,'max_move':float(np.max(np.linalg.norm(x-initial,axis=1))),'accepted':True}


def scan(obj,p,mark=False):
    bm=bmesh.new()
    try:
        bm.from_mesh(obj.data);bm.transform(obj.matrix_world)
        bm.verts.ensure_lookup_table();bm.edges.ensure_lookup_table();bm.faces.ensure_lookup_table()
        unit=p.id_data.unit_settings.scale_length
        tolerance=p.mesh_epsilon/max(unit,1e-8)
        degenerate=[f.index for f in bm.faces if f.calc_area()<tolerance*tolerance]
        duplicates=[];seen=set()
        for f in bm.faces:
            key=tuple(sorted(v.index for v in f.verts))
            if key in seen:duplicates.append(f.index)
            seen.add(key)
        pool=set(bm.verts);parts=[]
        while pool:
            first=pool.pop();queue=[first];members=[first]
            while queue:
                v=queue.pop()
                for edge in v.link_edges:
                    n=edge.other_vert(v)
                    if n in pool:pool.remove(n);queue.append(n);members.append(n)
            faces={f for v in members for f in v.link_faces}
            area=sum(f.calc_area() for f in faces)*unit*unit
            parts.append({'vertices':[v.index for v in members],'faces':sorted(f.index for f in faces),'area_m2':area})
        parts.sort(key=lambda x:(len(x['faces']),x['area_m2']),reverse=True)
        small=[part for part in parts[1:] if len(part['faces'])<=p.island_faces and part['area_m2']<=p.island_area]
        nonmanifold=[e for e in bm.edges if len(e.link_faces)>2]
        boundaries=[e for e in bm.edges if len(e.link_faces)==1]
        loose=[v.index for v in bm.verts if not v.link_faces]
        folds=fold_metrics(obj)
        flags=set(degenerate+duplicates+folds['fold_faces']+folds['stretch_faces'])
        flags.update(i for part in small for i in part['faces'])
        flags.update(f.index for e in nonmanifold for f in e.link_faces)
        if mark:
            attr=obj.data.attributes.get(FLAG) or obj.data.attributes.new(FLAG,'BOOLEAN','FACE')
            attr.data.foreach_set('value',[i in flags for i in range(len(obj.data.polygons))])
        return {'object':obj.name,'vertices':len(bm.verts),'faces':len(bm.faces),'components':len(parts),
                'loose_vertices':len(loose),'degenerate_faces':len(degenerate),'duplicate_faces':len(duplicates),
                'boundary_edges':len(boundaries),'nonmanifold_edges':len(nonmanifold),'small_islands':len(small),
                'fold_reference_available':folds['available'],'suspect_folds':len(folds['fold_faces']),
                'suspect_stretch':len(folds['stretch_faces']),'problem_faces':len(flags),
                '_small_faces':[i for part in small for i in part['faces']], '_flags':sorted(flags),
                '_degenerate':degenerate,'_duplicates':duplicates}
    finally:bm.free()


def active_meshes(p):
    if p.mesh_scope=='SOURCE':return core.selected_meshes(p)
    col=p.preview_collection if p.mesh_scope=='PREVIEW' else p.result_collection
    if not col:raise ValueError('请先生成要检测的预览或结果。')
    return [o for o in col.objects if o.type=='MESH' and o.get(core.OWNER)]


def public(report):return {k:v for k,v in report.items() if not k.startswith('_')}


def inspect_meshes(context,p):
    if context.object and context.object.mode!='OBJECT':bpy.ops.object.mode_set(mode='OBJECT')
    reports=[scan(o,p,mark=False) for o in active_meshes(p)]
    p.mesh_report=json.dumps([public(r) for r in reports],ensure_ascii=False,indent=2)
    p.message='网格检测完成：'+str(sum(r['problem_faces'] for r in reports))+' 个问题/疑似问题面。边界与小岛不一定是错误。'
    return reports


def repair_meshes(context,p):
    if p.mesh_scope=='SOURCE':raise ValueError('原模型只检测；请先生成预览，在副本上修复。')
    if context.object and context.object.mode!='OBJECT':bpy.ops.object.mode_set(mode='OBJECT')
    objects=active_meshes(p);backups=[];reports=[]
    try:
        for obj in objects:
            before=scan(obj,p);old=obj.data;obj.data=old.copy();backups.append((obj,old))
            old.use_fake_user=True
            obj['hur_geometry_backup']=old.name
            if p.repair_folds and reference(obj) is not None:stabilize(obj,p.fit_stability)
            bm=bmesh.new()
            try:
                bm.from_mesh(obj.data);bm.faces.ensure_lookup_table();bm.verts.ensure_lookup_table()
                # Only exact indexed duplicate faces and numerically degenerate faces by default.
                # Never weld all nearby vertices: UV seams, thin clothing and weights can differ.
                remove=set(before['_duplicates']+before['_degenerate'])
                if p.remove_islands:remove.update(before['_small_faces'])
                faces=[f for f in bm.faces if f.index in remove]
                if faces:bmesh.ops.delete(bm,geom=faces,context='FACES_ONLY')
                loose=[v for v in bm.verts if not v.link_faces]
                if loose:bmesh.ops.delete(bm,geom=loose,context='VERTS')
                if p.recalc_normals:bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
                bm.to_mesh(obj.data);obj.data.update()
            finally:bm.free()
            reports.append({'before':public(before),'after':public(scan(obj,p))})
        if p.mesh_scope=='PREVIEW':p.stage=2
        else:p.stage=3
        p.report='';p.mesh_report=json.dumps(reports,ensure_ascii=False,indent=2)
        p.message='副本网格修复完成；已保存修复前网格，可撤销。请重新检查/绑定。'
        return reports
    except Exception:
        for obj,old in backups:obj.data=old
        raise


def select_problems(context,p):
    objects=active_meshes(p)
    if not objects:raise ValueError('没有可检查的网格，请先选择源网格或生成预览/结果。')
    obj=context.object if context.object in objects else objects[0]
    if context.object and context.object.mode!='OBJECT':bpy.ops.object.mode_set(mode='OBJECT')
    report=scan(obj,p)
    core.activate(context,obj)
    if p.mesh_scope!='SOURCE':
        core.show_stage(p,'PREVIEW' if p.mesh_scope=='PREVIEW' else 'RESULT')
    for v in obj.data.vertices:v.select=False
    for e in obj.data.edges:e.select=False
    flags=set(report['_flags'])
    for f in obj.data.polygons:f.select=f.index in flags
    context.tool_settings.mesh_select_mode=(False,False,True)
    bpy.ops.object.mode_set(mode='EDIT')
    p.message=f'{obj.name}：已选择 {len(flags)} 个疑似问题面；人工检查后再删除小岛。'
