import bpy
import json
from pathlib import Path
from mathutils import Matrix
from . import core


def export_fbx(context,p,filepath):
    report=core.validate(p)
    path=Path(filepath)
    if path.suffix.lower()!='.fbx':path=path.with_suffix('.fbx')
    if not path.parent.is_dir():raise ValueError('导出目录不存在，请选择已有目录。')
    if not context.window:raise ValueError('导出需要 Blender 窗口上下文。')
    old_scene=context.window.scene
    previous_selection=list(context.selected_objects);previous_active=context.view_layer.objects.active
    original=p.result_rig
    old_arm=bpy.data.objects.get('Armature')
    old_arm_name=old_arm.name if old_arm else None
    temp=bpy.data.scenes.new('换绑_临时导出')
    temp.unit_settings.system='METRIC';temp.unit_settings.scale_length=.01
    clones=[];data_blocks=[]
    rig=None
    try:
        if context.object and context.object.mode!='OBJECT':bpy.ops.object.mode_set(mode='OBJECT')
        rig=original.copy();rig.data=original.data.copy();clones.append(rig);data_blocks.append(rig.data)
        temp.collection.objects.link(rig)
        if old_arm:old_arm.name='HUR_Temporary_Original_Armature'
        rig.name='Armature';rig.animation_data_clear();rig.parent=None;rig.matrix_world=Matrix.Identity(4)
        # Express reference-local geometry in centimeters without moving the original.
        factor=original.matrix_world.to_scale().x*old_scene.unit_settings.scale_length*100
        conversion=Matrix.Scale(factor,4)
        rig.data.transform(conversion)
        for pb in rig.pose.bones:
            pb.matrix_basis=Matrix.Identity(4)
            for c in list(pb.constraints):pb.constraints.remove(c)
        for obj in p.result_collection.objects:
            if obj.type!='MESH':continue
            clone=obj.copy();clone.data=obj.data.copy();clones.append(clone);data_blocks.append(clone.data)
            temp.collection.objects.link(clone);clone.animation_data_clear()
            clone.data.transform(conversion@original.matrix_world.inverted()@obj.matrix_world)
            clone.parent=rig;clone.matrix_parent_inverse=Matrix.Identity(4);clone.matrix_world=Matrix.Identity(4)
            for m in clone.modifiers:
                if m.type=='ARMATURE':m.object=rig
        context.window.scene=temp
        for obj in clones:
            obj.hide_viewport=False;obj.hide_render=False;obj.hide_set(False);obj.select_set(True)
        context.view_layer.objects.active=rig;context.view_layer.update()
        bpy.ops.export_scene.fbx(filepath=str(path),check_existing=False,use_selection=True,
            object_types={'ARMATURE','MESH'},global_scale=1,apply_unit_scale=True,apply_scale_options='FBX_SCALE_ALL',
            axis_forward='-Y',axis_up='Z',add_leaf_bones=False,use_armature_deform_only=False,
            armature_nodetype='NULL',bake_anim=False,use_custom_props=False,mesh_smooth_type='FACE',
            use_tspace=True,path_mode='COPY' if p.embed_textures else 'AUTO',embed_textures=p.embed_textures)
    finally:
        context.window.scene=old_scene
        for obj in clones:bpy.data.objects.remove(obj,do_unlink=True)
        for data in data_blocks:
            if data.users==0:
                if isinstance(data,bpy.types.Mesh):bpy.data.meshes.remove(data)
                elif isinstance(data,bpy.types.Armature):bpy.data.armatures.remove(data)
        bpy.data.scenes.remove(temp)
        if old_arm:old_arm.name=old_arm_name
        for obj in context.selected_objects:obj.select_set(False)
        for obj in previous_selection:
            if obj.name in context.view_layer.objects:obj.select_set(True)
        if previous_active and previous_active.name in context.view_layer.objects:context.view_layer.objects.active=previous_active
    if not path.is_file() or path.stat().st_size==0:raise ValueError('FBX 未成功写入。')
    report.update({'fbx':str(path),'unit':'centimeter','animation_exported':False,'textures_embedded':p.embed_textures})
    # Sidecar is useful, but a report permission failure must not disguise a successful FBX export.
    warning=''
    try:path.with_suffix('.report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    except OSError as exc:warning='（FBX 已导出，但检查报告写入失败：'+str(exc)+'）'
    p.last_export=str(path);p.stage=5;p.message='已导出 '+path.name+'。'+warning
    return str(path)
