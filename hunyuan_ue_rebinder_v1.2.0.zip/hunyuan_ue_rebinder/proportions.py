"""Create a separate UE-named reference rig for the source's current proportions.

This intentionally changes rest transforms and requires a separate UE Skeleton.
The existing source mesh pose becomes the new binding reference pose.
"""
import bpy
from mathutils import Matrix,Vector
from . import core


def create_reference(context,p):
    src,dst,objects,mapping=core.check_mapping(p)
    # Multiple source joints mapped to the same target do not define a unique position.
    inverse={}
    for s,t in mapping.items():
        if t in inverse:raise ValueError('保留体态需要一对一关节映射，请先解决合并到同一目标的映射：'+t)
        inverse[t]=s
    if not all(role in core.roles(src) and role in core.roles(dst) for role in ('pelvis','neck','head','upperarm_l','upperarm_r')):
        raise ValueError('保留体态需要可识别的骨盆、颈部、头部和双侧上臂。')
    context.view_layer.update()
    sh=lambda n:src.matrix_world@src.pose.bones[n].head
    th=lambda n:dst.matrix_world@dst.data.bones[n].head_local
    anchors={t:sh(s) for t,s in inverse.items()}
    sup,sfront=core.anatomical_basis(src,True);tup,tfront=core.anatomical_basis(dst)
    # Interpolate omitted spine/neck joints between their nearest mapped ancestors
    # and descendants, rather than inheriting one rigid offset for the whole chain.
    for b in dst.data.bones:
        if b.name in anchors:continue
        ancestor=next((a for a in b.parent_recursive if a.name in inverse),None)
        descendants=[d for d in dst.data.bones if d.name in inverse and b in d.parent_recursive]
        if ancestor and descendants:
            end=min(descendants,key=lambda d:len(d.parent_recursive))
            a,c=th(ancestor.name),th(end.name);edge=c-a
            t=max(0,min(1,(th(b.name)-a).dot(edge)/max(edge.length_squared,1e-12)))
            anchors[b.name]=anchors[ancestor.name].lerp(anchors[end.name],t)
    frames={}
    for t,s in inverse.items():
        b=dst.data.bones[t]
        descendants=[d for d in dst.data.bones if d.name in inverse and b in d.parent_recursive]
        if descendants:
            child=min(descendants,key=lambda d:len(d.parent_recursive)).name
            a,c=th(t),th(child);x,y=anchors[t],anchors[child]
        else:
            a=th(t);x=anchors[t]
            # UE imported display tails are not always along the anatomical limb.
            # Hand children supply the palm direction even without source fingers.
            rr=core.roles(dst);side=next((side for side in ('l','r') if rr.get('hand_'+side)==t),None)
            tip=rr.get('middle_03_'+side) if side else None
            c=th(tip) if tip else dst.matrix_world@b.tail_local
            y=src.matrix_world@src.pose.bones[s].tail
        rotation=core.frame(x,y,sfront).to_quaternion()@core.frame(a,c,tfront).to_quaternion().inverted()
        scale=(y-x).length/max((c-a).length,1e-7)
        # Scale for unmapped descendants; edit-bone axes only use rotation below.
        frames[t]=(Matrix.Translation(x)@rotation.to_matrix().to_4x4()@Matrix.Scale(scale,4)@Matrix.Translation(-a),rotation)
    ref=dst.copy();ref.data=dst.data.copy();ref.name='UE_体态参考_需独立Skeleton'
    context.scene.collection.objects.link(ref);ref.parent=None;ref.matrix_world=dst.matrix_world.copy();ref.animation_data_clear()
    ref['hur_custom_reference']=True
    ref['hur_requires_separate_skeleton']=True
    ref['hur_original_target']=dst.name
    for pb in ref.pose.bones:
        pb.matrix_basis=Matrix.Identity(4)
        for c in list(pb.constraints):pb.constraints.remove(c)
    inv=ref.matrix_world.inverted();worldq=dst.matrix_world.to_quaternion()
    edits={}
    for b in dst.data.bones:
        anchor_bone=b.name if b.name in frames else next((a.name for a in b.parent_recursive if a.name in frames),None)
        if anchor_bone:
            transform,rotation=frames[anchor_bone]
            head=anchors.get(b.name,transform@th(b.name))
            axis=rotation@(dst.matrix_world.to_3x3()@(b.tail_local-b.head_local))
            up=rotation@(worldq@b.z_axis)
            edits[b.name]=(inv@head,inv@(head+axis),inv.to_3x3()@up)
        else:
            edits[b.name]=(b.head_local.copy(),b.tail_local.copy(),b.z_axis.copy())
    core.activate(context,ref);bpy.ops.object.mode_set(mode='EDIT')
    try:
        for b in ref.data.edit_bones:b.use_connect=False
        for b in ref.data.edit_bones:
            b.head,b.tail,up=edits[b.name];b.align_roll(up)
    finally:bpy.ops.object.mode_set(mode='OBJECT')
    ref.show_in_front=False;ref.data.display_type='STICK'
    core.restore_inputs(p)
    p.target=ref
    core.inspect(context,p)
    p.fit_mode='ALIGNED';p.weight_method='SOURCE';p.smooth_steps=0
    p.message='已创建独立体态参考骨架，保留源当前外形。请生成预览和绑定；UE 中必须使用独立 Skeleton 并重定向动画。'
    return ref
