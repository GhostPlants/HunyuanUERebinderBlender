"""Conservative name matching. Unrecognized weighted bones require manual mapping."""
import re


def normalized(name):
    return re.sub(r'[^a-z0-9]', '', name.split(':')[-1].lower())


ALIASES = {
    'pelvis': ('pelvis', 'hips', 'hip'), 'head': ('head',),
    'neck': ('neck', 'neck01'),
}
for side, suffix in [('left', 'l'), ('right', 'r')]:
    for role, aliases in {
        'clavicle': (side+'shoulder', 'clavicle'+suffix),
        'upperarm': (side+'arm', 'upperarm'+suffix),
        'lowerarm': (side+'forearm', 'lowerarm'+suffix, 'forearm'+suffix),
        'hand': (side+'hand', 'hand'+suffix),
        'thigh': (side+'upleg', 'thigh'+suffix),
        'calf': (side+'leg', 'calf'+suffix, 'shin'+suffix),
        'foot': (side+'foot', 'foot'+suffix),
        'ball': (side+'toebase', 'ball'+suffix, 'toe'+suffix),
    }.items():
        ALIASES[role+'_'+suffix] = aliases
    for digit in ('thumb', 'index', 'middle', 'ring', 'pinky'):
        for segment in range(1, 4):
            ALIASES[f'{digit}_{segment:02}_{suffix}'] = (
                f'{side}hand{digit}{segment}', f'{digit}{segment:02}{suffix}')


def roles(rig):
    index = {normalized(b.name): b.name for b in rig.data.bones}
    result = {}
    for role, aliases in ALIASES.items():
        for alias in aliases:
            if alias in index:
                result[role] = index[alias]
                break
    return result


def spine_chain(rig):
    bones = [b for b in rig.data.bones if re.fullmatch(r'spine\d*', normalized(b.name))]
    return sorted(bones, key=lambda b: len(b.parent_recursive))


def auto_map(source, target):
    dest = {normalized(b.name): b.name for b in target.data.bones}
    mapping = {b.name: dest.get(normalized(b.name), '') for b in source.data.bones}
    sr, tr = roles(source), roles(target)
    for role, name in sr.items():
        if role in tr:
            mapping[name] = tr[role]
    sp, tp = spine_chain(source), spine_chain(target)
    for i, b in enumerate(sp):
        if tp:
            mapping[b.name] = tp[round(i * (len(tp)-1) / max(1, len(sp)-1))].name
    return mapping


def region(name, rig_roles):
    for role, bone_name in rig_roles.items():
        if name == bone_name:
            if role.endswith(('_l', '_r')):
                side = role[-1]
                return ('leg_' if role.startswith(('thigh', 'calf', 'foot', 'ball')) else 'arm_') + side
            return 'body'
    n = normalized(name)
    side = 'l' if n.endswith('l') or n.startswith('left') else 'r' if n.endswith('r') or n.startswith('right') else ''
    if side:
        if any(s in n for s in ('arm', 'hand', 'thumb', 'index', 'middle', 'ring', 'pinky', 'clavicle')):
            return 'arm_' + side
        if any(s in n for s in ('thigh', 'calf', 'foot', 'ball', 'leg')):
            return 'leg_' + side
    return 'body'


def is_finger(name):
    return any(d in normalized(name) for d in ('thumb', 'index', 'middle', 'ring', 'pinky'))


def is_helper(name):
    return name.lower().startswith('ik_') or normalized(name) in ('interaction', 'centerofmass')
